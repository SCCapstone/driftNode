#!/usr/bin/env python

#********WoooHooo!!! Imports!!********#
import rospy
from std_msgs.msg import String
from sensor_msgs.msg import Imu
#***********End 'O Imports************#

def callback(imu_msg):	#imu_msgs will become populated with the imu message from the talker
     #this all commented out for now while we're playing around with what values from the imu go where
    rospy.loginfo(rospy.get_caller_id()+
	" I heard: [ang_vel: %i %i %i  lin_accel: %i %i %i orient: %i %i %i]", 
	imu_msg.angular_velocity.x, 
	imu_msg.angular_velocity.y, 
	imu_msg.angular_velocity.z,

	imu_msg.linear_acceleration.x, 
	imu_msg.linear_acceleration.y,
	imu_msg.linear_acceleration.z,

	imu_msg.orientation.x,
	imu_msg.orientation.y,
	imu_msg.orientation.z)

    rospy.loginfo(rospy.get_caller_id())
    #rospy.loginfo(imu_msg)
    
def imu_listener():

    rospy.init_node('imu_listener', anonymous=True)	#declaring listener node
    rospy.Subscriber("imu_chatter", Imu, callback)	#subsrcibing to imu_chatter topic
    rospy.spin()	#WooHoo!! spinning 
        
if __name__ == '__main__':
    imu_listener()
