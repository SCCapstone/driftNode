#include <iostream>

namespace a {
  void foo() { 
    std::cout << __PRETTY_FUNCTION__ << "\n";
  }
}
