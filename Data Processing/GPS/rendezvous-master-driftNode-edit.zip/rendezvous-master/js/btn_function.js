//Customize the functions based on your needs
function f_btnCallback1()
{

}

function f_btnCallback2()
{	

}

function f_btnCallback3()
{

}

function f_btnCallback4()
{

}

function f_btnCallbackStart()
{

}

function f_btnCallbackWarning()
{

}

function f_btnCallbackStop()
{

}