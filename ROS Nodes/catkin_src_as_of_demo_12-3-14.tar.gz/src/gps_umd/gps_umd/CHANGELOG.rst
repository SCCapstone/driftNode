^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gps_umd
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.6
-----
* Initial catkin release
