  // Connecting to ROS
  // -----------------

  var ros_pub_msg = new ROSLIB.Ros({
    url : 'ws://localhost:9091'
  });

  //Add your publishing functions here